--To select all the rows and columns
Select * from customers

--To select a specified customer's info from an order in a specific date 
Select phonenumber,ordernumber from orders where orderdate = '01/02/2017'

--To select using Aliases
Select 
phonenumber as phone,
ordernumber as ord
from 
orders

--Limiting the results
Select top (10) phonenumber as phone ,firstname,lastname from customers 

--Select with concatenation
Select firstname + '(' + lastname + ')' from customers 

--Select performing wildcard searches
Select firstname,lastname from customers
where lastname like 'M____'

Select firstname,lastname from customers
where lastname like 'K%'

--Select as ASC or DESC
Select totalcost as Cost,ordernumber as # from orders 
where phonenumber = 70555333 
Order by totalcost asc







