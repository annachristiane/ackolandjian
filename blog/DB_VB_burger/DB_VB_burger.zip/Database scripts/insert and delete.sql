Delete from customers where phonenumber = 70997330

Insert into customers
(phonenumber,firstname,lastname,address)
Values 
(70123700,'Kevork','Kolandjian','Zahle')

