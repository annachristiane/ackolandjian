/*	Burger Database */

-- Create the database
CREATE DATABASE bur
GO

-- Set the simple recovery model
ALTER DATABASE bur SET RECOVERY SIMPLE


-- Use the burgerbar2 database for all following commands
USE bur

CREATE TABLE [dbo].[Login] (
    [Username] VARCHAR (25) NOT NULL,
    [Password] VARCHAR (50) NOT NULL
);



CREATE TABLE [dbo].[Customers] (
    [Phonenumber] INT           NOT NULL,
    [FirstName]   VARCHAR (25)  NOT NULL,
    [LastName]    VARCHAR (25)  NOT NULL,
    [Address]     VARCHAR (100) NULL,
    CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED ([Phonenumber] ASC)
);




CREATE TABLE [dbo].[Burgers] (
    [OrderNumber]   INT          IDENTITY (1, 1) NOT NULL,
    [Delivery]      VARCHAR (50) NOT NULL,
    [Cost]          MONEY        NOT NULL,
    [Size]          VARCHAR (50) NOT NULL,
    [Mushrooms]     VARCHAR (50) NOT NULL,
    [Blackolives]   VARCHAR (50) NOT NULL,
    [Mayo]          VARCHAR (50) NOT NULL,
    [Onions]        VARCHAR (50) NOT NULL,
    [Mustard]       VARCHAR (50) NOT NULL,
    [Pepperoni]     VARCHAR (50) NOT NULL,
    [Peppers]       VARCHAR (50) NOT NULL,
    [Beef]          VARCHAR (50) NOT NULL,
    [DoubleBeef]    VARCHAR (50) NOT NULL,
    [ChedderCheese] VARCHAR (50) NOT NULL,
    [Tortilla]      VARCHAR (50) NOT NULL,
    [Fish]          VARCHAR (50) NOT NULL,
    [Salads]        VARCHAR (50) NOT NULL,
    [ChickenBreast] VARCHAR (50) NOT NULL,
    [Fries]         VARCHAR (50) NOT NULL,
    [Avocado]       VARCHAR (50) NOT NULL,
    [Tomatoes]      VARCHAR (50) NOT NULL,
    [Jalapenos]     VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Burgers] PRIMARY KEY CLUSTERED ([OrderNumber] ASC)
	);


CREATE TABLE [dbo].[Orders] (
    [OrderNumber]     INT           IDENTITY (1, 1) NOT NULL,
    [PhoneNumber]     INT           NOT NULL,
    [OrderDate]       DATE          NOT NULL,
    [TotalCost]       INT           NOT NULL,
    [AdminUsername]   NVARCHAR (50) NOT NULL,
    [DeliveryManName] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderNumber] ASC),
    CONSTRAINT [FK_Orders_Burgers] FOREIGN KEY ([OrderNumber]) REFERENCES [dbo].[Burgers] ([OrderNumber]),
    CONSTRAINT [FK_Orders_Customers] FOREIGN KEY ([PhoneNumber]) REFERENCES [dbo].[Customers] ([Phonenumber])
);




CREATE TABLE [dbo].[Relation] (
    [Phonenumber] INT NOT NULL,
    [Ordernumber] INT IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_Relation_1] PRIMARY KEY CLUSTERED ([Ordernumber] ASC)
);

CREATE TABLE [dbo].[DelikveryMANINFO] (
    [DeliveryManID]   INT           IDENTITY (1, 1) NOT NULL,
    [DeliveryManName] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_DelikveryMANINFO] PRIMARY KEY CLUSTERED ([DeliveryManID] ASC)
);


--CREATE TABLE [dbo].[DeliveryMen] (
    --[DeliveryManID] INT           IDENTITY (1, 1) NOT NULL,
   -- [Ordernumber]   INT           NOT NULL,
   -- [Firstname]     NVARCHAR (25) NOT NULL,
   -- [Lastname]      NVARCHAR (25) NOT NULL,
   -- [Age]           INT           NOT NULL,
   -- [Sex]           NVARCHAR (8)  NOT NULL,
   -- [Phonenumber]   INT           NOT NULL,
   -- CONSTRAINT [PK_DeliveryMen] PRIMARY KEY CLUSTERED ([DeliveryManID] ASC),
   -- CONSTRAINT [FK_DeliveryMen_DeliveryMen] FOREIGN KEY ([Ordernumber]) REFERENCES [dbo].[Orders] ([OrderNumber])
--);

-- Create Customers data

INSERT INTO [dbo].[Customers] VALUES ( 70123444,'Holay', 'Ora','Beirut')
INSERT INTO Customers VALUES ( 70268660 ,'Hovo','Kolandjian', 'Zahle')
INSERT INTO Customers VALUES ( 70376926,'Christian','Khalil', 'sed el baouchrieh')
INSERT INTO Customers VALUES ( 70382186,'Dee','Marlow', 'Arax')
INSERT INTO Customers VALUES ( 70406728,'Theresa','Doulz', 'Jbeil')
INSERT INTO Customers VALUES ( 70555333,'Mimoza','Maria', 'Sour')
INSERT INTO Customers VALUES ( 70997222,'Salim','Barakat', 'Sayda')
INSERT INTO Customers VALUES ( 70997330,'Harper','Pitt', 'Baalbak')
INSERT INTO Customers VALUES ( 71112699,'Karl','Moten', 'Sour')
INSERT INTO Customers VALUES ( 71329835,'Rita-Eliane','Kolandjian', 'Bourj Hammoud')
INSERT INTO Customers VALUES ( 71456127,'Kevin','Vegas', 'Jdeide')
INSERT INTO Customers VALUES ( 76153123,'Alan','Charles', 'Beirut')
INSERT INTO Customers VALUES ( 76472485,'Olivia','Kong', 'Jounieh')

INSERT INTO Login VALUES ( 'vbuser','123b')

--INSERT INTO DeliveryMen VALUES (null,'Ali','Kamil',20, 'Male',71888999 )
--INSERT INTO DeliveryMen VALUES (null,'Samir','Ishak',24,'Male',76432123 )
--INSERT INTO DeliveryMen VALUES (null,'Tamara','Zaher',22,'Female',76432100 )
--INSERT INTO DeliveryMen VALUES (null,'Elie','Iskandar',21,'Male',71455123 )
--INSERT INTO DeliveryMen VALUES (null,'Maher','Khawand',24,'Male',76437723 )
--INSERT INTO DeliveryMen VALUES (null,'Joe','Touma',27,'Male',71232123 )
--INSERT INTO DeliveryMen VALUES (null,'Samir','Ishak',24,'Male',76432123 )


INSERT INTO [dbo].[DelikveryMANINFO] VALUES ( 'Mariane123')
INSERT INTO [dbo].[DelikveryMANINFO] VALUES ( 'AliSameh')
INSERT INTO [dbo].[DelikveryMANINFO] VALUES ( 'MarounZ')
INSERT INTO [dbo].[DelikveryMANINFO] VALUES ( 'Salim')
INSERT INTO [dbo].[DelikveryMANINFO] VALUES ( 'Fares')


