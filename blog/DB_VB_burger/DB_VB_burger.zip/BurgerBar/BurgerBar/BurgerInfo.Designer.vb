﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BurgerInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BurgerInfo))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkdeliver = New System.Windows.Forms.CheckBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.chkjalapenos = New System.Windows.Forms.CheckBox()
        Me.chktortilla = New System.Windows.Forms.CheckBox()
        Me.chkfish = New System.Windows.Forms.CheckBox()
        Me.chkbeef = New System.Windows.Forms.CheckBox()
        Me.chkmustard = New System.Windows.Forms.CheckBox()
        Me.chkMushrooms = New System.Windows.Forms.CheckBox()
        Me.chkolives = New System.Windows.Forms.CheckBox()
        Me.chkfries = New System.Windows.Forms.CheckBox()
        Me.chkdoublebeef = New System.Windows.Forms.CheckBox()
        Me.chkonions = New System.Windows.Forms.CheckBox()
        Me.chkchicken = New System.Windows.Forms.CheckBox()
        Me.chkchedder = New System.Windows.Forms.CheckBox()
        Me.chkmayo = New System.Windows.Forms.CheckBox()
        Me.chkpeppers = New System.Windows.Forms.CheckBox()
        Me.chkpepperoni = New System.Windows.Forms.CheckBox()
        Me.chksalads = New System.Windows.Forms.CheckBox()
        Me.chktomatoes = New System.Windows.Forms.CheckBox()
        Me.chkavocado = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rdosmall = New System.Windows.Forms.RadioButton()
        Me.rdomedium = New System.Windows.Forms.RadioButton()
        Me.rdolarge = New System.Windows.Forms.RadioButton()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.OrderNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeliveryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SizeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MushroomsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BlackolivesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MayoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OnionsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MustardDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PepperoniDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PeppersDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BeefDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DoubleBeefDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChedderCheeseDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TortillaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FishDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SaladsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChickenBreastDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FriesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AvocadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TomatoesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.JalapenosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BurgersBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet5 = New BurgerBar.BurgerDataSet5()
        Me.BurgerDataSet = New BurgerBar.BurgerDataSet()
        Me.BurgersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgersTableAdapter = New BurgerBar.BurgerDataSetTableAdapters.BurgersTableAdapter()
        Me.Fill = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RelationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet1 = New BurgerBar.BurgerDataSet1()
        Me.RelationTableAdapter = New BurgerBar.BurgerDataSet1TableAdapters.RelationTableAdapter()
        Me.txtphone = New System.Windows.Forms.TextBox()
        Me.PhoneNumber = New System.Windows.Forms.Label()
        Me.BurgerDataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RelationBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet2 = New BurgerBar.BurgerDataSet2()
        Me.BurgersBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgersTableAdapter1 = New BurgerBar.BurgerDataSet2TableAdapters.BurgersTableAdapter()
        Me.BurgerDataSet3 = New BurgerBar.BurgerDataSet3()
        Me.BurgersBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgersTableAdapter2 = New BurgerBar.BurgerDataSet3TableAdapters.BurgersTableAdapter()
        Me.BurgersTableAdapter3 = New BurgerBar.BurgerDataSet5TableAdapters.BurgersTableAdapter()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.OrdersBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet10 = New BurgerBar.BurgerDataSet10()
        Me.OrdersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet7 = New BurgerBar.BurgerDataSet7()
        Me.OrdersTableAdapter = New BurgerBar.BurgerDataSet7TableAdapters.OrdersTableAdapter()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.prndoc = New System.Drawing.Printing.PrintDocument()
        Me.btnprint = New System.Windows.Forms.Button()
        Me.txtnotes = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.OrdersTableAdapter1 = New BurgerBar.BurgerDataSet10TableAdapters.OrdersTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.BurgerDataSet11 = New BurgerBar.BurgerDataSet11()
        Me.OrdersBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrdersTableAdapter2 = New BurgerBar.BurgerDataSet11TableAdapters.OrdersTableAdapter()
        Me.BurgerDataSet12 = New BurgerBar.BurgerDataSet12()
        Me.OrdersBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrdersTableAdapter3 = New BurgerBar.BurgerDataSet12TableAdapters.OrdersTableAdapter()
        Me.BurgerDataSet13 = New BurgerBar.BurgerDataSet13()
        Me.OrdersBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrdersTableAdapter4 = New BurgerBar.BurgerDataSet13TableAdapters.OrdersTableAdapter()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Service = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgersBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RelationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RelationBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgersBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgersBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.BurgerDataSet11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrdersBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.chkdeliver)
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox3.Location = New System.Drawing.Point(35, 861)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(332, 94)
        Me.GroupBox3.TabIndex = 31
        Me.GroupBox3.TabStop = False
        '
        'chkdeliver
        '
        Me.chkdeliver.AutoSize = True
        Me.chkdeliver.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkdeliver.Location = New System.Drawing.Point(10, 21)
        Me.chkdeliver.Name = "chkdeliver"
        Me.chkdeliver.Size = New System.Drawing.Size(179, 61)
        Me.chkdeliver.TabIndex = 0
        Me.chkdeliver.Text = "Deliver"
        Me.chkdeliver.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox7.Controls.Add(Me.chkjalapenos)
        Me.GroupBox7.Controls.Add(Me.chktortilla)
        Me.GroupBox7.Controls.Add(Me.chkfish)
        Me.GroupBox7.Controls.Add(Me.chkbeef)
        Me.GroupBox7.Controls.Add(Me.chkmustard)
        Me.GroupBox7.Controls.Add(Me.chkMushrooms)
        Me.GroupBox7.Controls.Add(Me.chkolives)
        Me.GroupBox7.Controls.Add(Me.chkfries)
        Me.GroupBox7.Controls.Add(Me.chkdoublebeef)
        Me.GroupBox7.Controls.Add(Me.chkonions)
        Me.GroupBox7.Controls.Add(Me.chkchicken)
        Me.GroupBox7.Controls.Add(Me.chkchedder)
        Me.GroupBox7.Controls.Add(Me.chkmayo)
        Me.GroupBox7.Controls.Add(Me.chkpeppers)
        Me.GroupBox7.Controls.Add(Me.chkpepperoni)
        Me.GroupBox7.Controls.Add(Me.chksalads)
        Me.GroupBox7.Controls.Add(Me.chktomatoes)
        Me.GroupBox7.Controls.Add(Me.chkavocado)
        Me.GroupBox7.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox7.Location = New System.Drawing.Point(384, 21)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(786, 934)
        Me.GroupBox7.TabIndex = 29
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Toppings"
        '
        'chkjalapenos
        '
        Me.chkjalapenos.AutoSize = True
        Me.chkjalapenos.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkjalapenos.Location = New System.Drawing.Point(103, 821)
        Me.chkjalapenos.Name = "chkjalapenos"
        Me.chkjalapenos.Size = New System.Drawing.Size(220, 61)
        Me.chkjalapenos.TabIndex = 49
        Me.chkjalapenos.Text = "Jalapenos"
        Me.chkjalapenos.UseVisualStyleBackColor = True
        '
        'chktortilla
        '
        Me.chktortilla.AutoSize = True
        Me.chktortilla.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chktortilla.Location = New System.Drawing.Point(469, 821)
        Me.chktortilla.Name = "chktortilla"
        Me.chktortilla.Size = New System.Drawing.Size(183, 61)
        Me.chktortilla.TabIndex = 48
        Me.chktortilla.Text = "Tortilla"
        Me.chktortilla.UseVisualStyleBackColor = True
        '
        'chkfish
        '
        Me.chkfish.AutoSize = True
        Me.chkfish.Location = New System.Drawing.Point(103, 629)
        Me.chkfish.Name = "chkfish"
        Me.chkfish.Size = New System.Drawing.Size(127, 61)
        Me.chkfish.TabIndex = 47
        Me.chkfish.Text = "Fish"
        Me.chkfish.UseVisualStyleBackColor = True
        '
        'chkbeef
        '
        Me.chkbeef.AutoSize = True
        Me.chkbeef.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkbeef.Location = New System.Drawing.Point(482, 259)
        Me.chkbeef.Name = "chkbeef"
        Me.chkbeef.Size = New System.Drawing.Size(127, 61)
        Me.chkbeef.TabIndex = 39
        Me.chkbeef.Text = "Beef"
        Me.chkbeef.UseVisualStyleBackColor = True
        '
        'chkmustard
        '
        Me.chkmustard.AutoSize = True
        Me.chkmustard.Location = New System.Drawing.Point(103, 720)
        Me.chkmustard.Name = "chkmustard"
        Me.chkmustard.Size = New System.Drawing.Size(201, 61)
        Me.chkmustard.TabIndex = 46
        Me.chkmustard.Text = "Mustard"
        Me.chkmustard.UseVisualStyleBackColor = True
        '
        'chkMushrooms
        '
        Me.chkMushrooms.AutoSize = True
        Me.chkMushrooms.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMushrooms.Location = New System.Drawing.Point(107, 83)
        Me.chkMushrooms.Name = "chkMushrooms"
        Me.chkMushrooms.Size = New System.Drawing.Size(251, 61)
        Me.chkMushrooms.TabIndex = 36
        Me.chkMushrooms.Text = "Mushrooms"
        Me.chkMushrooms.UseVisualStyleBackColor = True
        '
        'chkolives
        '
        Me.chkolives.AutoSize = True
        Me.chkolives.Location = New System.Drawing.Point(469, 720)
        Me.chkolives.Name = "chkolives"
        Me.chkolives.Size = New System.Drawing.Size(263, 61)
        Me.chkolives.TabIndex = 45
        Me.chkolives.Text = "Black olives"
        Me.chkolives.UseVisualStyleBackColor = True
        '
        'chkfries
        '
        Me.chkfries.AutoSize = True
        Me.chkfries.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkfries.Location = New System.Drawing.Point(482, 83)
        Me.chkfries.Name = "chkfries"
        Me.chkfries.Size = New System.Drawing.Size(137, 61)
        Me.chkfries.TabIndex = 38
        Me.chkfries.Text = "Fries"
        Me.chkfries.UseVisualStyleBackColor = True
        '
        'chkdoublebeef
        '
        Me.chkdoublebeef.AutoSize = True
        Me.chkdoublebeef.Location = New System.Drawing.Point(469, 538)
        Me.chkdoublebeef.Name = "chkdoublebeef"
        Me.chkdoublebeef.Size = New System.Drawing.Size(259, 61)
        Me.chkdoublebeef.TabIndex = 44
        Me.chkdoublebeef.Text = "Double beef"
        Me.chkdoublebeef.UseVisualStyleBackColor = True
        '
        'chkonions
        '
        Me.chkonions.AutoSize = True
        Me.chkonions.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkonions.Location = New System.Drawing.Point(107, 170)
        Me.chkonions.Name = "chkonions"
        Me.chkonions.Size = New System.Drawing.Size(172, 61)
        Me.chkonions.TabIndex = 37
        Me.chkonions.Text = "Onions"
        Me.chkonions.UseVisualStyleBackColor = True
        '
        'chkchicken
        '
        Me.chkchicken.AutoSize = True
        Me.chkchicken.Location = New System.Drawing.Point(103, 538)
        Me.chkchicken.Name = "chkchicken"
        Me.chkchicken.Size = New System.Drawing.Size(187, 61)
        Me.chkchicken.TabIndex = 43
        Me.chkchicken.Text = "Chicken"
        Me.chkchicken.UseVisualStyleBackColor = True
        '
        'chkchedder
        '
        Me.chkchedder.AutoSize = True
        Me.chkchedder.Location = New System.Drawing.Point(107, 452)
        Me.chkchedder.Name = "chkchedder"
        Me.chkchedder.Size = New System.Drawing.Size(306, 61)
        Me.chkchedder.TabIndex = 37
        Me.chkchedder.Text = "Chedder cheese"
        Me.chkchedder.UseVisualStyleBackColor = True
        '
        'chkmayo
        '
        Me.chkmayo.AutoSize = True
        Me.chkmayo.Location = New System.Drawing.Point(482, 452)
        Me.chkmayo.Name = "chkmayo"
        Me.chkmayo.Size = New System.Drawing.Size(149, 61)
        Me.chkmayo.TabIndex = 42
        Me.chkmayo.Text = "Mayo"
        Me.chkmayo.UseVisualStyleBackColor = True
        '
        'chkpeppers
        '
        Me.chkpeppers.AutoSize = True
        Me.chkpeppers.Location = New System.Drawing.Point(107, 259)
        Me.chkpeppers.Name = "chkpeppers"
        Me.chkpeppers.Size = New System.Drawing.Size(183, 61)
        Me.chkpeppers.TabIndex = 36
        Me.chkpeppers.Text = "Peppers"
        Me.chkpeppers.UseVisualStyleBackColor = True
        '
        'chkpepperoni
        '
        Me.chkpepperoni.AutoSize = True
        Me.chkpepperoni.Location = New System.Drawing.Point(482, 359)
        Me.chkpepperoni.Name = "chkpepperoni"
        Me.chkpepperoni.Size = New System.Drawing.Size(223, 61)
        Me.chkpepperoni.TabIndex = 41
        Me.chkpepperoni.Text = "Pepperoni"
        Me.chkpepperoni.UseVisualStyleBackColor = True
        '
        'chksalads
        '
        Me.chksalads.AutoSize = True
        Me.chksalads.Location = New System.Drawing.Point(107, 359)
        Me.chksalads.Name = "chksalads"
        Me.chksalads.Size = New System.Drawing.Size(163, 61)
        Me.chksalads.TabIndex = 38
        Me.chksalads.Text = "Salads"
        Me.chksalads.UseVisualStyleBackColor = True
        '
        'chktomatoes
        '
        Me.chktomatoes.AutoSize = True
        Me.chktomatoes.Location = New System.Drawing.Point(482, 170)
        Me.chktomatoes.Name = "chktomatoes"
        Me.chktomatoes.Size = New System.Drawing.Size(213, 61)
        Me.chktomatoes.TabIndex = 40
        Me.chktomatoes.Text = "Tomatoes"
        Me.chktomatoes.UseVisualStyleBackColor = True
        '
        'chkavocado
        '
        Me.chkavocado.AutoSize = True
        Me.chkavocado.Location = New System.Drawing.Point(469, 629)
        Me.chkavocado.Name = "chkavocado"
        Me.chkavocado.Size = New System.Drawing.Size(200, 61)
        Me.chkavocado.TabIndex = 39
        Me.chkavocado.Text = "Avocado"
        Me.chkavocado.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.rdosmall)
        Me.GroupBox2.Controls.Add(Me.rdomedium)
        Me.GroupBox2.Controls.Add(Me.rdolarge)
        Me.GroupBox2.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(35, 298)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(332, 295)
        Me.GroupBox2.TabIndex = 30
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Size"
        '
        'rdosmall
        '
        Me.rdosmall.AutoSize = True
        Me.rdosmall.Checked = True
        Me.rdosmall.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdosmall.Location = New System.Drawing.Point(7, 59)
        Me.rdosmall.Name = "rdosmall"
        Me.rdosmall.Size = New System.Drawing.Size(147, 61)
        Me.rdosmall.TabIndex = 19
        Me.rdosmall.TabStop = True
        Me.rdosmall.Text = "Small"
        Me.rdosmall.UseVisualStyleBackColor = True
        '
        'rdomedium
        '
        Me.rdomedium.AutoSize = True
        Me.rdomedium.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdomedium.Location = New System.Drawing.Point(7, 123)
        Me.rdomedium.Name = "rdomedium"
        Me.rdomedium.Size = New System.Drawing.Size(193, 61)
        Me.rdomedium.TabIndex = 20
        Me.rdomedium.Text = "Medium"
        Me.rdomedium.UseVisualStyleBackColor = True
        '
        'rdolarge
        '
        Me.rdolarge.AutoSize = True
        Me.rdolarge.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdolarge.Location = New System.Drawing.Point(10, 181)
        Me.rdolarge.Name = "rdolarge"
        Me.rdolarge.Size = New System.Drawing.Size(148, 61)
        Me.rdolarge.TabIndex = 21
        Me.rdolarge.Text = "Large"
        Me.rdolarge.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Enabled = False
        Me.PictureBox3.ErrorImage = Global.BurgerBar.My.Resources.Resources.mono_exit
        Me.PictureBox3.Image = Global.BurgerBar.My.Resources.Resources.erase_512
        Me.PictureBox3.Location = New System.Drawing.Point(194, 63)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(63, 63)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 22
        Me.PictureBox3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox3, "Exit")
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.ErrorImage = Global.BurgerBar.My.Resources.Resources.arrow_back_512
        Me.PictureBox2.Image = Global.BurgerBar.My.Resources.Resources.arrow_back_512
        Me.PictureBox2.Location = New System.Drawing.Point(42, 54)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(80, 81)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 22
        Me.PictureBox2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox2, "Back")
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderNumberDataGridViewTextBoxColumn, Me.DeliveryDataGridViewTextBoxColumn, Me.CostDataGridViewTextBoxColumn, Me.SizeDataGridViewTextBoxColumn, Me.MushroomsDataGridViewTextBoxColumn, Me.BlackolivesDataGridViewTextBoxColumn, Me.MayoDataGridViewTextBoxColumn, Me.OnionsDataGridViewTextBoxColumn, Me.MustardDataGridViewTextBoxColumn, Me.PepperoniDataGridViewTextBoxColumn, Me.PeppersDataGridViewTextBoxColumn, Me.BeefDataGridViewTextBoxColumn, Me.DoubleBeefDataGridViewTextBoxColumn, Me.ChedderCheeseDataGridViewTextBoxColumn, Me.TortillaDataGridViewTextBoxColumn, Me.FishDataGridViewTextBoxColumn, Me.SaladsDataGridViewTextBoxColumn, Me.ChickenBreastDataGridViewTextBoxColumn, Me.FriesDataGridViewTextBoxColumn, Me.AvocadoDataGridViewTextBoxColumn, Me.TomatoesDataGridViewTextBoxColumn, Me.JalapenosDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BurgersBindingSource3
        Me.DataGridView1.Location = New System.Drawing.Point(1299, 45)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(527, 271)
        Me.DataGridView1.TabIndex = 36
        '
        'OrderNumberDataGridViewTextBoxColumn
        '
        Me.OrderNumberDataGridViewTextBoxColumn.DataPropertyName = "OrderNumber"
        Me.OrderNumberDataGridViewTextBoxColumn.HeaderText = "OrderNumber"
        Me.OrderNumberDataGridViewTextBoxColumn.Name = "OrderNumberDataGridViewTextBoxColumn"
        Me.OrderNumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DeliveryDataGridViewTextBoxColumn
        '
        Me.DeliveryDataGridViewTextBoxColumn.DataPropertyName = "Delivery"
        Me.DeliveryDataGridViewTextBoxColumn.HeaderText = "Delivery"
        Me.DeliveryDataGridViewTextBoxColumn.Name = "DeliveryDataGridViewTextBoxColumn"
        Me.DeliveryDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CostDataGridViewTextBoxColumn
        '
        Me.CostDataGridViewTextBoxColumn.DataPropertyName = "Cost"
        Me.CostDataGridViewTextBoxColumn.HeaderText = "Cost"
        Me.CostDataGridViewTextBoxColumn.Name = "CostDataGridViewTextBoxColumn"
        Me.CostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SizeDataGridViewTextBoxColumn
        '
        Me.SizeDataGridViewTextBoxColumn.DataPropertyName = "Size"
        Me.SizeDataGridViewTextBoxColumn.HeaderText = "Size"
        Me.SizeDataGridViewTextBoxColumn.Name = "SizeDataGridViewTextBoxColumn"
        Me.SizeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MushroomsDataGridViewTextBoxColumn
        '
        Me.MushroomsDataGridViewTextBoxColumn.DataPropertyName = "Mushrooms"
        Me.MushroomsDataGridViewTextBoxColumn.HeaderText = "Mushrooms"
        Me.MushroomsDataGridViewTextBoxColumn.Name = "MushroomsDataGridViewTextBoxColumn"
        Me.MushroomsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BlackolivesDataGridViewTextBoxColumn
        '
        Me.BlackolivesDataGridViewTextBoxColumn.DataPropertyName = "Blackolives"
        Me.BlackolivesDataGridViewTextBoxColumn.HeaderText = "Blackolives"
        Me.BlackolivesDataGridViewTextBoxColumn.Name = "BlackolivesDataGridViewTextBoxColumn"
        Me.BlackolivesDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MayoDataGridViewTextBoxColumn
        '
        Me.MayoDataGridViewTextBoxColumn.DataPropertyName = "Mayo"
        Me.MayoDataGridViewTextBoxColumn.HeaderText = "Mayo"
        Me.MayoDataGridViewTextBoxColumn.Name = "MayoDataGridViewTextBoxColumn"
        Me.MayoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'OnionsDataGridViewTextBoxColumn
        '
        Me.OnionsDataGridViewTextBoxColumn.DataPropertyName = "Onions"
        Me.OnionsDataGridViewTextBoxColumn.HeaderText = "Onions"
        Me.OnionsDataGridViewTextBoxColumn.Name = "OnionsDataGridViewTextBoxColumn"
        Me.OnionsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MustardDataGridViewTextBoxColumn
        '
        Me.MustardDataGridViewTextBoxColumn.DataPropertyName = "Mustard"
        Me.MustardDataGridViewTextBoxColumn.HeaderText = "Mustard"
        Me.MustardDataGridViewTextBoxColumn.Name = "MustardDataGridViewTextBoxColumn"
        Me.MustardDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PepperoniDataGridViewTextBoxColumn
        '
        Me.PepperoniDataGridViewTextBoxColumn.DataPropertyName = "Pepperoni"
        Me.PepperoniDataGridViewTextBoxColumn.HeaderText = "Pepperoni"
        Me.PepperoniDataGridViewTextBoxColumn.Name = "PepperoniDataGridViewTextBoxColumn"
        Me.PepperoniDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PeppersDataGridViewTextBoxColumn
        '
        Me.PeppersDataGridViewTextBoxColumn.DataPropertyName = "Peppers"
        Me.PeppersDataGridViewTextBoxColumn.HeaderText = "Peppers"
        Me.PeppersDataGridViewTextBoxColumn.Name = "PeppersDataGridViewTextBoxColumn"
        Me.PeppersDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BeefDataGridViewTextBoxColumn
        '
        Me.BeefDataGridViewTextBoxColumn.DataPropertyName = "Beef"
        Me.BeefDataGridViewTextBoxColumn.HeaderText = "Beef"
        Me.BeefDataGridViewTextBoxColumn.Name = "BeefDataGridViewTextBoxColumn"
        Me.BeefDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DoubleBeefDataGridViewTextBoxColumn
        '
        Me.DoubleBeefDataGridViewTextBoxColumn.DataPropertyName = "DoubleBeef"
        Me.DoubleBeefDataGridViewTextBoxColumn.HeaderText = "DoubleBeef"
        Me.DoubleBeefDataGridViewTextBoxColumn.Name = "DoubleBeefDataGridViewTextBoxColumn"
        Me.DoubleBeefDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ChedderCheeseDataGridViewTextBoxColumn
        '
        Me.ChedderCheeseDataGridViewTextBoxColumn.DataPropertyName = "ChedderCheese"
        Me.ChedderCheeseDataGridViewTextBoxColumn.HeaderText = "ChedderCheese"
        Me.ChedderCheeseDataGridViewTextBoxColumn.Name = "ChedderCheeseDataGridViewTextBoxColumn"
        Me.ChedderCheeseDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TortillaDataGridViewTextBoxColumn
        '
        Me.TortillaDataGridViewTextBoxColumn.DataPropertyName = "Tortilla"
        Me.TortillaDataGridViewTextBoxColumn.HeaderText = "Tortilla"
        Me.TortillaDataGridViewTextBoxColumn.Name = "TortillaDataGridViewTextBoxColumn"
        Me.TortillaDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FishDataGridViewTextBoxColumn
        '
        Me.FishDataGridViewTextBoxColumn.DataPropertyName = "Fish"
        Me.FishDataGridViewTextBoxColumn.HeaderText = "Fish"
        Me.FishDataGridViewTextBoxColumn.Name = "FishDataGridViewTextBoxColumn"
        Me.FishDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SaladsDataGridViewTextBoxColumn
        '
        Me.SaladsDataGridViewTextBoxColumn.DataPropertyName = "Salads"
        Me.SaladsDataGridViewTextBoxColumn.HeaderText = "Salads"
        Me.SaladsDataGridViewTextBoxColumn.Name = "SaladsDataGridViewTextBoxColumn"
        Me.SaladsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ChickenBreastDataGridViewTextBoxColumn
        '
        Me.ChickenBreastDataGridViewTextBoxColumn.DataPropertyName = "ChickenBreast"
        Me.ChickenBreastDataGridViewTextBoxColumn.HeaderText = "ChickenBreast"
        Me.ChickenBreastDataGridViewTextBoxColumn.Name = "ChickenBreastDataGridViewTextBoxColumn"
        Me.ChickenBreastDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FriesDataGridViewTextBoxColumn
        '
        Me.FriesDataGridViewTextBoxColumn.DataPropertyName = "Fries"
        Me.FriesDataGridViewTextBoxColumn.HeaderText = "Fries"
        Me.FriesDataGridViewTextBoxColumn.Name = "FriesDataGridViewTextBoxColumn"
        Me.FriesDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AvocadoDataGridViewTextBoxColumn
        '
        Me.AvocadoDataGridViewTextBoxColumn.DataPropertyName = "Avocado"
        Me.AvocadoDataGridViewTextBoxColumn.HeaderText = "Avocado"
        Me.AvocadoDataGridViewTextBoxColumn.Name = "AvocadoDataGridViewTextBoxColumn"
        Me.AvocadoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TomatoesDataGridViewTextBoxColumn
        '
        Me.TomatoesDataGridViewTextBoxColumn.DataPropertyName = "Tomatoes"
        Me.TomatoesDataGridViewTextBoxColumn.HeaderText = "Tomatoes"
        Me.TomatoesDataGridViewTextBoxColumn.Name = "TomatoesDataGridViewTextBoxColumn"
        Me.TomatoesDataGridViewTextBoxColumn.ReadOnly = True
        '
        'JalapenosDataGridViewTextBoxColumn
        '
        Me.JalapenosDataGridViewTextBoxColumn.DataPropertyName = "Jalapenos"
        Me.JalapenosDataGridViewTextBoxColumn.HeaderText = "Jalapenos"
        Me.JalapenosDataGridViewTextBoxColumn.Name = "JalapenosDataGridViewTextBoxColumn"
        Me.JalapenosDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BurgersBindingSource3
        '
        Me.BurgersBindingSource3.DataMember = "Burgers"
        Me.BurgersBindingSource3.DataSource = Me.BurgerDataSet5
        '
        'BurgerDataSet5
        '
        Me.BurgerDataSet5.DataSetName = "BurgerDataSet5"
        Me.BurgerDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BurgerDataSet
        '
        Me.BurgerDataSet.DataSetName = "BurgerDataSet"
        Me.BurgerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BurgersBindingSource
        '
        Me.BurgersBindingSource.DataMember = "Burgers"
        Me.BurgersBindingSource.DataSource = Me.BurgerDataSet
        '
        'BurgersTableAdapter
        '
        Me.BurgersTableAdapter.ClearBeforeFill = True
        '
        'Fill
        '
        Me.Fill.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Fill.Location = New System.Drawing.Point(1299, 322)
        Me.Fill.Name = "Fill"
        Me.Fill.Size = New System.Drawing.Size(114, 34)
        Me.Fill.TabIndex = 37
        Me.Fill.Text = "Fill"
        Me.Fill.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(1299, 909)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 34)
        Me.Button1.TabIndex = 38
        Me.Button1.Text = "Fill"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RelationBindingSource
        '
        Me.RelationBindingSource.DataMember = "Relation"
        Me.RelationBindingSource.DataSource = Me.BurgerDataSet1
        '
        'BurgerDataSet1
        '
        Me.BurgerDataSet1.DataSetName = "BurgerDataSet1"
        Me.BurgerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RelationTableAdapter
        '
        Me.RelationTableAdapter.ClearBeforeFill = True
        '
        'txtphone
        '
        Me.txtphone.Enabled = False
        Me.txtphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtphone.Location = New System.Drawing.Point(35, 230)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(332, 45)
        Me.txtphone.TabIndex = 40
        '
        'PhoneNumber
        '
        Me.PhoneNumber.AutoSize = True
        Me.PhoneNumber.BackColor = System.Drawing.Color.Transparent
        Me.PhoneNumber.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhoneNumber.ForeColor = System.Drawing.Color.White
        Me.PhoneNumber.Location = New System.Drawing.Point(32, 150)
        Me.PhoneNumber.Name = "PhoneNumber"
        Me.PhoneNumber.Size = New System.Drawing.Size(288, 57)
        Me.PhoneNumber.TabIndex = 41
        Me.PhoneNumber.Text = "Phone Number"
        '
        'BurgerDataSet1BindingSource
        '
        Me.BurgerDataSet1BindingSource.DataSource = Me.BurgerDataSet1
        Me.BurgerDataSet1BindingSource.Position = 0
        '
        'RelationBindingSource1
        '
        Me.RelationBindingSource1.DataMember = "Relation"
        Me.RelationBindingSource1.DataSource = Me.BurgerDataSet1BindingSource
        '
        'BurgerDataSet2
        '
        Me.BurgerDataSet2.DataSetName = "BurgerDataSet2"
        Me.BurgerDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BurgersBindingSource1
        '
        Me.BurgersBindingSource1.DataMember = "Burgers"
        Me.BurgersBindingSource1.DataSource = Me.BurgerDataSet2
        '
        'BurgersTableAdapter1
        '
        Me.BurgersTableAdapter1.ClearBeforeFill = True
        '
        'BurgerDataSet3
        '
        Me.BurgerDataSet3.DataSetName = "BurgerDataSet3"
        Me.BurgerDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BurgersBindingSource2
        '
        Me.BurgersBindingSource2.DataMember = "Burgers"
        Me.BurgersBindingSource2.DataSource = Me.BurgerDataSet3
        '
        'BurgersTableAdapter2
        '
        Me.BurgersTableAdapter2.ClearBeforeFill = True
        '
        'BurgersTableAdapter3
        '
        Me.BurgersTableAdapter3.ClearBeforeFill = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Maroon
        Me.ImageList1.Images.SetKeyName(0, "1")
        Me.ImageList1.Images.SetKeyName(1, "2")
        Me.ImageList1.Images.SetKeyName(2, "3")
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.ErrorImage = Global.BurgerBar.My.Resources.Resources.home_5121
        Me.PictureBox1.Image = Global.BurgerBar.My.Resources.Resources.home_512
        Me.PictureBox1.Location = New System.Drawing.Point(121, 63)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(67, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 44
        Me.PictureBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox1, "Home")
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Image = Global.BurgerBar.My.Resources.Resources.PNGPIX_COM_French_Fries_PNG_Transparent_Image
        Me.PictureBox4.Location = New System.Drawing.Point(35, 640)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(332, 182)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 45
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.ErrorImage = Global.BurgerBar.My.Resources.Resources.hamburger_icon
        Me.PictureBox5.Image = Global.BurgerBar.My.Resources.Resources.hamburger_icon
        Me.PictureBox5.Location = New System.Drawing.Point(1299, 380)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(147, 131)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 46
        Me.PictureBox5.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox5, "Build Burger")
        '
        'OrdersBindingSource1
        '
        Me.OrdersBindingSource1.DataMember = "Orders"
        Me.OrdersBindingSource1.DataSource = Me.BurgerDataSet10
        '
        'BurgerDataSet10
        '
        Me.BurgerDataSet10.DataSetName = "BurgerDataSet10"
        Me.BurgerDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrdersBindingSource
        '
        Me.OrdersBindingSource.DataMember = "Orders"
        Me.OrdersBindingSource.DataSource = Me.BurgerDataSet7
        '
        'BurgerDataSet7
        '
        Me.BurgerDataSet7.DataSetName = "BurgerDataSet7"
        Me.BurgerDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrdersTableAdapter
        '
        Me.OrdersTableAdapter.ClearBeforeFill = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(1582, 909)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 34)
        Me.Button2.TabIndex = 48
        Me.Button2.Text = "Fill"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'prndoc
        '
        '
        'btnprint
        '
        Me.btnprint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprint.Location = New System.Drawing.Point(212, 21)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(114, 34)
        Me.btnprint.TabIndex = 49
        Me.btnprint.Text = "Print receipt"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'txtnotes
        '
        Me.txtnotes.Enabled = False
        Me.txtnotes.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnotes.Location = New System.Drawing.Point(47, 23)
        Me.txtnotes.Name = "txtnotes"
        Me.txtnotes.Size = New System.Drawing.Size(112, 28)
        Me.txtnotes.TabIndex = 50
        Me.txtnotes.Visible = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Mariane123", "AliSameh", "MarounZ", "Salim", "Fares"})
        Me.ComboBox1.Location = New System.Drawing.Point(25, 58)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(234, 24)
        Me.ComboBox1.TabIndex = 51
        '
        'OrdersTableAdapter1
        '
        Me.OrdersTableAdapter1.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Service)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(1461, 322)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(365, 100)
        Me.GroupBox1.TabIndex = 52
        Me.GroupBox1.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.txtnotes)
        Me.GroupBox4.Controls.Add(Me.btnprint)
        Me.GroupBox4.Location = New System.Drawing.Point(1461, 434)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(365, 77)
        Me.GroupBox4.TabIndex = 50
        Me.GroupBox4.TabStop = False
        '
        'BurgerDataSet11
        '
        Me.BurgerDataSet11.DataSetName = "BurgerDataSet11"
        Me.BurgerDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrdersBindingSource2
        '
        Me.OrdersBindingSource2.DataMember = "Orders"
        Me.OrdersBindingSource2.DataSource = Me.BurgerDataSet11
        '
        'OrdersTableAdapter2
        '
        Me.OrdersTableAdapter2.ClearBeforeFill = True
        '
        'BurgerDataSet12
        '
        Me.BurgerDataSet12.DataSetName = "BurgerDataSet12"
        Me.BurgerDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrdersBindingSource3
        '
        Me.OrdersBindingSource3.DataMember = "Orders"
        Me.OrdersBindingSource3.DataSource = Me.BurgerDataSet12
        '
        'OrdersTableAdapter3
        '
        Me.OrdersTableAdapter3.ClearBeforeFill = True
        '
        'BurgerDataSet13
        '
        Me.BurgerDataSet13.DataSetName = "BurgerDataSet13"
        Me.BurgerDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OrdersBindingSource4
        '
        Me.OrdersBindingSource4.DataMember = "Orders"
        Me.OrdersBindingSource4.DataSource = Me.BurgerDataSet13
        '
        'OrdersTableAdapter4
        '
        Me.OrdersTableAdapter4.ClearBeforeFill = True
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(1582, 529)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 24
        Me.DataGridView3.Size = New System.Drawing.Size(295, 374)
        Me.DataGridView3.TabIndex = 53
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(1299, 529)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.Size = New System.Drawing.Size(246, 374)
        Me.DataGridView2.TabIndex = 54
        '
        'Service
        '
        Me.Service.AutoSize = True
        Me.Service.Font = New System.Drawing.Font("Monotype Corsiva", 16.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Service.Location = New System.Drawing.Point(19, 18)
        Me.Service.Name = "Service"
        Me.Service.Size = New System.Drawing.Size(157, 34)
        Me.Service.TabIndex = 52
        Me.Service.Text = "Service helper:"
        '
        'BurgerInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.BurgerBar.My.Resources.Resources.tumblr_static_r
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1914, 999)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PhoneNumber)
        Me.Controls.Add(Me.txtphone)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Fill)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Name = "BurgerInfo"
        Me.Text = "text"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgersBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RelationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RelationBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgersBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgersBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.BurgerDataSet11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrdersBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents chkdeliver As CheckBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents chkbeef As CheckBox
    Friend WithEvents chkMushrooms As CheckBox
    Friend WithEvents chkfries As CheckBox
    Friend WithEvents chkonions As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rdosmall As RadioButton
    Friend WithEvents rdomedium As RadioButton
    Friend WithEvents rdolarge As RadioButton
    Friend WithEvents chkfish As CheckBox
    Friend WithEvents chkmustard As CheckBox
    Friend WithEvents chkolives As CheckBox
    Friend WithEvents chkdoublebeef As CheckBox
    Friend WithEvents chkchicken As CheckBox
    Friend WithEvents chkchedder As CheckBox
    Friend WithEvents chkmayo As CheckBox
    Friend WithEvents chkpeppers As CheckBox
    Friend WithEvents chkpepperoni As CheckBox
    Friend WithEvents chksalads As CheckBox
    Friend WithEvents chktomatoes As CheckBox
    Friend WithEvents chkavocado As CheckBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents BurgerDataSet As BurgerDataSet
    Friend WithEvents BurgersBindingSource As BindingSource
    Friend WithEvents BurgersTableAdapter As BurgerDataSetTableAdapters.BurgersTableAdapter
    Friend WithEvents Fill As Button
    Friend WithEvents chktortilla As CheckBox
    Friend WithEvents chkjalapenos As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents BurgerDataSet1 As BurgerDataSet1
    Friend WithEvents RelationBindingSource As BindingSource
    Friend WithEvents RelationTableAdapter As BurgerDataSet1TableAdapters.RelationTableAdapter
    Friend WithEvents txtphone As TextBox
    Friend WithEvents PhoneNumber As Label
    Friend WithEvents BurgerDataSet1BindingSource As BindingSource
    Friend WithEvents RelationBindingSource1 As BindingSource
    Friend WithEvents BurgerDataSet2 As BurgerDataSet2
    Friend WithEvents BurgersBindingSource1 As BindingSource
    Friend WithEvents BurgersTableAdapter1 As BurgerDataSet2TableAdapters.BurgersTableAdapter
    Friend WithEvents OrderNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CostDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SizeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MushroomsDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BlackolivesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MayoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OnionsDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MustardDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PepperoniDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PeppersDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BeefDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DoubleBeefDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ChedderCheeseDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TortillaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FishDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SaladsDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ChickenBreastDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FriesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AvocadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TomatoesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents JalapenosDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BurgerDataSet3 As BurgerDataSet3
    Friend WithEvents BurgersBindingSource2 As BindingSource
    Friend WithEvents BurgersTableAdapter2 As BurgerDataSet3TableAdapters.BurgersTableAdapter
    Friend WithEvents BurgerDataSet5 As BurgerDataSet5
    Friend WithEvents BurgersBindingSource3 As BindingSource
    Friend WithEvents BurgersTableAdapter3 As BurgerDataSet5TableAdapters.BurgersTableAdapter
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents BurgerDataSet7 As BurgerDataSet7
    Friend WithEvents OrdersBindingSource As BindingSource
    Friend WithEvents OrdersTableAdapter As BurgerDataSet7TableAdapters.OrdersTableAdapter
    Friend WithEvents Button2 As Button
    Friend WithEvents prndoc As Printing.PrintDocument
    Friend WithEvents btnprint As Button
    Friend WithEvents txtnotes As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents BurgerDataSet10 As BurgerDataSet10
    Friend WithEvents OrdersBindingSource1 As BindingSource
    Friend WithEvents OrdersTableAdapter1 As BurgerDataSet10TableAdapters.OrdersTableAdapter
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents BurgerDataSet11 As BurgerDataSet11
    Friend WithEvents OrdersBindingSource2 As BindingSource
    Friend WithEvents OrdersTableAdapter2 As BurgerDataSet11TableAdapters.OrdersTableAdapter
    Friend WithEvents BurgerDataSet12 As BurgerDataSet12
    Friend WithEvents OrdersBindingSource3 As BindingSource
    Friend WithEvents OrdersTableAdapter3 As BurgerDataSet12TableAdapters.OrdersTableAdapter
    Friend WithEvents BurgerDataSet13 As BurgerDataSet13
    Friend WithEvents OrdersBindingSource4 As BindingSource
    Friend WithEvents OrdersTableAdapter4 As BurgerDataSet13TableAdapters.OrdersTableAdapter
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Service As Label
End Class
