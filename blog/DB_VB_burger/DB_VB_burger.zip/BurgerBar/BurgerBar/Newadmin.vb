﻿
Imports System.Data.SqlClient
Imports System.Data
Public Class Newadmin
    Private Sub TextBoxusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connection As New SqlConnection("server=Anna-christina; database=burger; integrated security=true")
        Dim commandd As New SqlCommand("Select * from login where username=@username", connection)
        commandd.Parameters.Add("@username", SqlDbType.VarChar).Value = txtusername.Text
        Dim adapterr As New SqlDataAdapter(commandd)
        Dim tablee As New DataTable()
        adapterr.Fill(tablee)

        If IsNumeric(txtpassword.Text) = True Then
            MessageBox.Show("You have to put minimum one letter in your password")
        End If

        If txtusername.Text = "" Or txtpassword.Text = "" Or IsNumeric(txtusername.Text) = True Or IsNumeric(txtpassword.Text) = True Or txtpassword.Text <> txtpassword2.Text Then
            MessageBox.Show("Make sure to fill every box and check your passwords.")
        ElseIf tablee.Rows.Count > 0 Then
            MessageBox.Show("Invalid Username.")
        ElseIf tablee.Rows.Count <= 0 Then


            Dim command As New SqlCommand("Select * from login where password=@password", connection)
            command.Parameters.Add("@password", SqlDbType.VarChar).Value = txtadminpass.Text

            Dim adapter As New SqlDataAdapter(command)
            Dim table As New DataTable()
            adapter.Fill(table)

            If table.Rows.Count <= 0 Then
                MessageBox.Show("Username or password are invalid")
            Else
                MessageBox.Show("Verified!")
                btnregister.enabled = True
            End If


        End If



    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub



    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Choose.Show()

    End Sub

    Private Sub Newadmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BurgerDataSet9.Login' table. You can move, or remove it, as needed.
        Me.LoginTableAdapter.Fill(Me.BurgerDataSet9.Login)
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub fill_Click(sender As Object, e As EventArgs) Handles fill.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from login", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnregister.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        Dim sqlquery As String = "insert login(username,password)Values(@username,@password)"
        Dim commanddd As New SqlCommand(sqlquery, connection)
        commanddd.Parameters.Add("@username", SqlDbType.NVarChar).Value = txtusername.Text
        commanddd.Parameters.Add("@password", SqlDbType.NVarChar).Value = txtpassword.Text

        connection.Open()
        commanddd.ExecuteNonQuery()
        commanddd.Parameters.Clear()
        connection.Close()
        MessageBox.Show("A new Admin has been registered!")
        btnregister.Enabled = False

    End Sub
End Class