﻿

Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Windows.Forms
Imports System.Data.Sql
Imports System.Data
Public Class CustomersInfo
    Private Sub CustomersInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.OrdersTableAdapter.Fill(Me.BurgerDataSet6.Orders)
        Me.WindowState = FormWindowState.Maximized
        MessageBox.Show("Make sure to put month,day,year")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from orders", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub

    Private Sub MaskedTextBox1_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles txtorderdate.MaskInputRejected

    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click




        Dim conn As SqlConnection = New SqlConnection()
        conn.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"
        conn.Open()
        Dim sqlqueryy As String = "Select max(ordernumber) from orders "
        Dim commando As New SqlCommand(sqlqueryy, conn)
        Dim maxo As Integer = DirectCast(commando.ExecuteScalar(), Integer)
        commando.ExecuteNonQuery()
        commando.Parameters.Clear()
        conn.Close()
        Dim a As String = txtorderdate.Text



        If a.Length = 10 Then

            Dim connection As SqlConnection = New SqlConnection()
                connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

                Dim sqlquery As String = "Select ordernumber from orders where orderdate=@orderdate "
                Dim command As New SqlCommand(sqlquery, connection)
                command.Parameters.Add("@orderdate", SqlDbType.Date).Value = txtorderdate.Text

                Dim adapter As New SqlDataAdapter(command)
                Dim table As New DataTable()
            Try
                adapter.Fill(table)
                If table.Rows.Count > 0 Then
                    For Each dr As DataRow In table.Rows
                        ListBox1.Items.Add(dr(0))
                    Next
                Else MessageBox.Show("There's no order on the date mentioned")

                End If

                connection.Open()
                command.ExecuteNonQuery()
                command.Parameters.Clear()
                connection.Close()
            Catch ex As System.FormatException
                MsgBox("Try to write month,day,year.")

            End Try







        Else
            MessageBox.Show("The orders of today aren't finished yet or make sure to fill the void numbers by zeros")

        End If








    End Sub

    Private Sub btnFindphone_Click(sender As Object, e As EventArgs) Handles btnFindphone.Click
        Dim ing As Integer
        ing = ListBox1.Items(ListBox1.SelectedIndex)

        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

        Dim sqlquery As String = "Select phonenumber from relation where ordernumber=@ordernumber "
        Dim command As New SqlCommand(sqlquery, connection)
        command.Parameters.Add("@ordernumber", SqlDbType.Int).Value = ing
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count > 0 Then
            For Each dr As DataRow In table.Rows
                txtphone.Text = dr(0)
            Next
        Else MessageBox.Show("There's no order on the date mentioned")
        End If


    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Choose.Show()

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Close()

    End Sub
End Class