--Join Select where customer's name = Admin's username 
Select dbo.Customers.FirstName,dbo.Customers.LastName,[dbo].[Customers].[Address],[dbo].[Login].[Password]
from [dbo].[Customers]
inner join [dbo].[Login]
on [dbo].[Customers].[FirstName]=[dbo].[Login].[Username] 

--Join select where both are equal so customer = Admin (Ka mabda2)
select dbo.Customers.FirstName,dbo.Customers.LastName,[dbo].[Customers].[Address],[dbo].[Login].[Password]
from [dbo].[Customers]
inner join [dbo].[Login]
on [dbo].[Customers].[FirstName]=[dbo].[Login].[Username] and [dbo].[Customers].[LastName]=[dbo].[Login].[Password]

