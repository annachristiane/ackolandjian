﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Login
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized

    End Sub
    Public user As String
    Public pass As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
            Dim connection As New SqlConnection("server=Anna-christina; database=burger; integrated security=true")
            Dim command As New SqlCommand("Select * from login where username=@username and password=@password", connection)
            command.Parameters.Add("@username", SqlDbType.VarChar).Value = TextBoxusername.Text
            command.Parameters.Add("@password", SqlDbType.VarChar).Value = TextBoxpassword.Text

            Dim adapter As New SqlDataAdapter(command)
            Dim table As New DataTable()
            adapter.Fill(table)

            If table.Rows.Count <= 0 Then
                MessageBox.Show("Username or password are invalid")

            Else
            user = TextBoxusername.Text
            pass = TextBoxpassword.Text

            Me.Hide()
            Choose.Show()


        End If


        End Sub



    Private Sub TextBoxpassword_TextChanged(sender As Object, e As EventArgs) Handles TextBoxpassword.TextChanged

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBoxusername_TextChanged(sender As Object, e As EventArgs) Handles TextBoxusername.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("www.ACKBurgerhood.lb.com")

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Me.Hide()

    End Sub
End Class