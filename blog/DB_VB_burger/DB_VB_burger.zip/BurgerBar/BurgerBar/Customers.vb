﻿
Imports System.Data.SqlClient
Imports System.Windows.Forms
Imports System.Data.Sql
Imports System.Data

Public Class Customers
    Public currentphone As Integer
    Private Sub Customers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BurgerDataSet8.Customers' table. You can move, or remove it, as needed.
        Me.CustomersTableAdapter.Fill(Me.BurgerDataSet8.Customers)
        Me.WindowState = FormWindowState.Maximized

        lblDate.Text = Format(Now, "d")
        txtphone.Focus()
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from customers", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Public Sub executequery(query As String)
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

        Dim command As New SqlCommand(query, connection)


        connection.Open()
        command.ExecuteNonQuery()
        connection.Close()
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

        Dim sqlquery As String = "Select * from customers where phonenumber=@phonenumber"
        Dim command As New SqlCommand(sqlquery, connection)

        If txtfirstname.Text = "" Then
            ErrorProvider1.SetError(txtfirstname, "Fill the firstname.")

        End If

        If txtlastname.Text = "" Then
            ErrorProvider1.SetError(txtlastname, "Fill the lastname.")

        End If

        If txtaddress.Text = "" Then
            ErrorProvider1.SetError(txtaddress, "Fill the Address.")
        End If

        Dim nam As String = txtfirstname.Text
        Dim sp As Integer = 1
        For i = 0 To nam.Length - 1
            If (Asc(nam(i)) >= Asc("A") And Asc(nam(i)) <= Asc("Z")) Or (Asc(nam(i)) >= Asc("a") And Asc(nam(i)) <= Asc("z")) Then
            Else
                sp = 2
            End If
        Next


        Dim name As String = txtlastname.Text
        Dim spo As Integer = 1
        For i = 0 To name.Length - 1
            If (Asc(name(i)) >= Asc("A") And Asc(name(i)) <= Asc("Z")) Or (Asc(name(i)) >= Asc("a") And Asc(name(i)) <= Asc("z")) Then

            Else
                spo = 2
            End If
        Next

        Dim namee As String = txtaddress.Text
        Dim spos As Integer = 1
        For i = 0 To namee.Length - 1
            If (Asc(namee(i)) >= Asc("A") And Asc(namee(i)) <= Asc("Z")) Or (Asc(namee(i)) >= Asc("a") And Asc(namee(i)) <= Asc("z")) Then

            Else
                spos = 2
            End If
        Next


        If spo = 1 And sp = 1 And spos = 1 Then
            If txtfirstname.Text <> "" And txtlastname.Text <> "" And txtaddress.Text <> "" And IsNumeric(txtfirstname.Text) = False And IsNumeric(txtlastname.Text) = False And IsNumeric(txtaddress.Text) = False Then
                Dim updatequery As String = "Update customers set firstname='" & txtfirstname.Text & "',lastname='" & txtlastname.Text & "',address='" & txtaddress.Text & "' where phonenumber= " & txtphone.Text & ""
                executequery(updatequery)
            End If
        Else
            MessageBox.Show("Invalid First name or Last name")
            btnsave.Enabled = True




        End If



    End Sub



    Private Sub txtlastname_TextChanged(sender As Object, e As EventArgs) Handles txtlastname.TextChanged

    End Sub

    Private Sub btnFind_Click(sender As Object, e As EventArgs) Handles btnFind.Click

        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

        Dim sqlquery As String = "Select * from customers where phonenumber=@phonenumber"
        Dim command As New SqlCommand(sqlquery, connection)
        command.Parameters.Add("@Phonenumber", SqlDbType.Int).Value = txtphone.Text
        currentphone = txtphone.Text
        BurgerInfo.txtphone.Text = currentphone
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()
        adapter.Fill(table)

        If table.Rows.Count > 0 Then
            btnFind.Enabled = False
            Label2.Enabled = False
            txtphone.Enabled = False
            btnsave.Enabled = True
            btnadd.Enabled = False

            txtfirstname.Enabled = True
            txtlastname.Enabled = True
            txtaddress.Enabled = True
            Label3.Enabled = True
            Label4.Enabled = True
            Label6.Enabled = True


            txtfirstname.Text = table.Rows(0)(1).ToString()
            txtlastname.Text = table.Rows(0)(2).ToString()
            txtaddress.Text = table.Rows(0)(3).ToString()
            btnnext.Enabled = True

        Else
            btnsave.Enabled = False
            btnadd.Enabled = True
            txtfirstname.Enabled = True
            txtlastname.Enabled = True
            txtaddress.Enabled = True
            Label3.Enabled = True
            Label4.Enabled = True
            Label6.Enabled = True
            btnFind.Enabled = False
        End If
        connection.Open()
        command.ExecuteNonQuery()
        command.Parameters.Clear()
        connection.Close()


        Dim L As Integer
        L = Len(txtphone.Text)



    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"



        If txtfirstname.Text = "" Then
            ErrorProvider1.SetError(txtfirstname, "Fill the firstname.")

        End If

        If txtlastname.Text = "" Then
            ErrorProvider1.SetError(txtlastname, "Fill the lastname.")

        End If

        If txtaddress.Text = "" Then
            ErrorProvider1.SetError(txtaddress, "Fill the Address.")
        End If

        Dim nam As String = txtfirstname.Text
        Dim sp As Integer
        For i = 0 To nam.Length - 1
            If (Asc(nam(i)) >= Asc("A") And Asc(nam(i)) <= Asc("Z")) Or (Asc(nam(i)) >= Asc("a") And Asc(nam(i)) <= Asc("z")) Then
                sp = 1
            Else sp = 2
            End If
        Next


        Dim name As String = txtlastname.Text
        Dim spo As Integer
        For i = 0 To name.Length - 1
            If (Asc(name(i)) >= Asc("A") And Asc(name(i)) <= Asc("Z")) Or (Asc(name(i)) >= Asc("a") And Asc(name(i)) <= Asc("z")) Then
                spo = 1
            Else
                spo = 2
            End If
        Next

        Dim namee As String = txtaddress.Text
        Dim spos As Integer
        For i = 0 To namee.Length - 1
            If (Asc(namee(i)) >= Asc("A") And Asc(namee(i)) <= Asc("Z")) Or (Asc(namee(i)) >= Asc("a") And Asc(namee(i)) <= Asc("z")) Then
                spos = 1
            Else
                spos = 2
            End If
        Next

        If spo = 1 And sp = 1 And spos = 1 Then
            If txtfirstname.Text <> "" And txtlastname.Text <> "" And txtaddress.Text <> "" Then
                Dim sqlqueryy As String = "insert customers(Phonenumber,Firstname,Lastname,Address)Values(@Phonenumber,@Firstname,@Lastname,@Address)"
                Dim commandd As New SqlCommand(sqlqueryy, connection)

                btnnext.Enabled = True


                commandd.Parameters.Add("@phonenumber", SqlDbType.VarChar).Value = txtphone.Text
                commandd.Parameters.Add("@Firstname", SqlDbType.VarChar).Value = txtfirstname.Text
                commandd.Parameters.Add("@Lastname", SqlDbType.VarChar).Value = txtlastname.Text
                commandd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtaddress.Text

                connection.Open()
                commandd.ExecuteNonQuery()
                commandd.Parameters.Clear()
                connection.Close()
            End If
        Else
            MessageBox.Show("Invalid first name, last name or address!")
            btnadd.Enabled = True
        End If


        btnnext.Enabled = True
        btnadd.Enabled = False
        ' not to add two times, phonenumber is a primary key
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        txtphone.Text = ""
        txtfirstname.Text = ""
        txtlastname.Text = ""
        txtaddress.Text = ""

        Label2.Enabled = True
        btnFind.Enabled = True
        txtfirstname.Enabled = False
        txtlastname.Enabled = False
        txtaddress.Enabled = False
        Label3.Enabled = False
        Label4.Enabled = False
        Label6.Enabled = False
        btnsave.Enabled = False
        btnadd.Enabled = False

        txtphone.Enabled = True
        btnnext.Enabled = False

    End Sub




    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub

    Private Sub grptoppings_Enter(sender As Object, e As EventArgs)

    End Sub
    Private Sub btncomplete_Click(sender As Object, e As EventArgs)

    End Sub





    Public f As String
    Public l As String
    Public a As String
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnnext.Click
        f = txtfirstname.Text
        l = txtlastname.Text
        a = txtaddress.Text

        Me.Hide()
        BurgerInfo.Show()




    End Sub

    Private Sub txtfirstname_TextChanged(sender As Object, e As EventArgs) Handles txtfirstname.TextChanged
        If txtfirstname.Text = "" Then

        End If
    End Sub

    Private Sub grpinfo_Enter(sender As Object, e As EventArgs) Handles grpinfo.Enter

    End Sub
End Class