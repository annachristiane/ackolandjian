update Customers
set firstname='Harper'
where lastname = 'pitt'


