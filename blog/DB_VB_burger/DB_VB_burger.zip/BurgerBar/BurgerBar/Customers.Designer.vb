﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Customers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.grpOrder = New System.Windows.Forms.GroupBox()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.grpinfo = New System.Windows.Forms.GroupBox()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnFind = New System.Windows.Forms.Button()
        Me.txtphone = New System.Windows.Forms.MaskedTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtlastname = New System.Windows.Forms.TextBox()
        Me.txtfirstname = New System.Windows.Forms.TextBox()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnnext = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CustomersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BurgerDataSet8 = New BurgerBar.BurgerDataSet8()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.CustomersTableAdapter = New BurgerBar.BurgerDataSet8TableAdapters.CustomersTableAdapter()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.grpOrder.SuspendLayout()
        Me.grpinfo.SuspendLayout()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BurgerDataSet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpOrder
        '
        Me.grpOrder.BackColor = System.Drawing.Color.Transparent
        Me.grpOrder.Controls.Add(Me.lblDate)
        Me.grpOrder.Controls.Add(Me.Label5)
        Me.grpOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpOrder.Location = New System.Drawing.Point(37, 26)
        Me.grpOrder.Margin = New System.Windows.Forms.Padding(4)
        Me.grpOrder.Name = "grpOrder"
        Me.grpOrder.Padding = New System.Windows.Forms.Padding(4)
        Me.grpOrder.Size = New System.Drawing.Size(627, 121)
        Me.grpOrder.TabIndex = 32
        Me.grpOrder.TabStop = False
        '
        'lblDate
        '
        Me.lblDate.BackColor = System.Drawing.Color.White
        Me.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(275, 43)
        Me.lblDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(277, 40)
        Me.lblDate.TabIndex = 5
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 29)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(225, 57)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Order Date"
        '
        'grpinfo
        '
        Me.grpinfo.BackColor = System.Drawing.Color.Transparent
        Me.grpinfo.Controls.Add(Me.btnadd)
        Me.grpinfo.Controls.Add(Me.btnFind)
        Me.grpinfo.Controls.Add(Me.txtphone)
        Me.grpinfo.Controls.Add(Me.Label2)
        Me.grpinfo.Controls.Add(Me.txtlastname)
        Me.grpinfo.Controls.Add(Me.txtfirstname)
        Me.grpinfo.Controls.Add(Me.txtaddress)
        Me.grpinfo.Controls.Add(Me.btncancel)
        Me.grpinfo.Controls.Add(Me.btnsave)
        Me.grpinfo.Controls.Add(Me.Label4)
        Me.grpinfo.Controls.Add(Me.Label3)
        Me.grpinfo.Controls.Add(Me.Label6)
        Me.grpinfo.Font = New System.Drawing.Font("Monotype Corsiva", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpinfo.Location = New System.Drawing.Point(37, 154)
        Me.grpinfo.Name = "grpinfo"
        Me.grpinfo.Size = New System.Drawing.Size(744, 763)
        Me.grpinfo.TabIndex = 33
        Me.grpinfo.TabStop = False
        Me.grpinfo.Text = "Information"
        '
        'btnadd
        '
        Me.btnadd.Enabled = False
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(196, 672)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(144, 45)
        Me.btnadd.TabIndex = 28
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btnFind
        '
        Me.btnFind.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFind.Location = New System.Drawing.Point(541, 128)
        Me.btnFind.Margin = New System.Windows.Forms.Padding(4)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.Size = New System.Drawing.Size(174, 48)
        Me.btnFind.TabIndex = 27
        Me.btnFind.Text = "Find Customer"
        Me.btnFind.UseVisualStyleBackColor = True
        '
        'txtphone
        '
        Me.txtphone.Font = New System.Drawing.Font("Monotype Corsiva", 22.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtphone.Location = New System.Drawing.Point(312, 128)
        Me.txtphone.Margin = New System.Windows.Forms.Padding(4)
        Me.txtphone.Mask = "########"
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(192, 49)
        Me.txtphone.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(34, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(141, 57)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Phone:"
        '
        'txtlastname
        '
        Me.txtlastname.Enabled = False
        Me.txtlastname.Font = New System.Drawing.Font("Monotype Corsiva", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlastname.Location = New System.Drawing.Point(312, 414)
        Me.txtlastname.MaxLength = 25
        Me.txtlastname.Name = "txtlastname"
        Me.txtlastname.Size = New System.Drawing.Size(288, 45)
        Me.txtlastname.TabIndex = 7
        '
        'txtfirstname
        '
        Me.txtfirstname.Enabled = False
        Me.txtfirstname.Font = New System.Drawing.Font("Monotype Corsiva", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfirstname.Location = New System.Drawing.Point(312, 271)
        Me.txtfirstname.MaxLength = 25
        Me.txtfirstname.Name = "txtfirstname"
        Me.txtfirstname.Size = New System.Drawing.Size(273, 45)
        Me.txtfirstname.TabIndex = 6
        '
        'txtaddress
        '
        Me.txtaddress.Enabled = False
        Me.txtaddress.Font = New System.Drawing.Font("Monotype Corsiva", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.Location = New System.Drawing.Point(312, 556)
        Me.txtaddress.MaxLength = 100
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(326, 45)
        Me.txtaddress.TabIndex = 5
        '
        'btncancel
        '
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(521, 672)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(148, 45)
        Me.btncancel.TabIndex = 4
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Enabled = False
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(43, 672)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(133, 45)
        Me.btnsave.TabIndex = 3
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Enabled = False
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(34, 556)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(169, 57)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Enabled = False
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(34, 402)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(214, 57)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Last name:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Enabled = False
        Me.Label6.Font = New System.Drawing.Font("Monotype Corsiva", 28.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(34, 271)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(220, 57)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "First name:"
        '
        'btnnext
        '
        Me.btnnext.Enabled = False
        Me.btnnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnext.Location = New System.Drawing.Point(1553, 768)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(158, 61)
        Me.btnnext.TabIndex = 43
        Me.btnnext.Text = "Next"
        Me.btnnext.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(1553, 536)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(158, 61)
        Me.btnexit.TabIndex = 42
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(1082, 536)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(158, 61)
        Me.Button1.TabIndex = 41
        Me.Button1.Text = "Fill"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CustomersBindingSource
        '
        Me.CustomersBindingSource.DataMember = "Customers"
        Me.CustomersBindingSource.DataSource = Me.BurgerDataSet8
        '
        'BurgerDataSet8
        '
        Me.BurgerDataSet8.DataSetName = "BurgerDataSet8"
        Me.BurgerDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'CustomersTableAdapter
        '
        Me.CustomersTableAdapter.ClearBeforeFill = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(1082, 188)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(629, 310)
        Me.DataGridView1.TabIndex = 44
        '
        'Customers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.BurgerBar.My.Resources.Resources.vh5CVRx
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1736, 912)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnnext)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.grpOrder)
        Me.Controls.Add(Me.grpinfo)
        Me.Name = "Customers"
        Me.Text = "Customers"
        Me.grpOrder.ResumeLayout(False)
        Me.grpOrder.PerformLayout()
        Me.grpinfo.ResumeLayout(False)
        Me.grpinfo.PerformLayout()
        CType(Me.CustomersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BurgerDataSet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpOrder As GroupBox
    Friend WithEvents lblDate As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents grpinfo As GroupBox
    Friend WithEvents btnadd As Button
    Friend WithEvents btnFind As Button
    Friend WithEvents txtphone As MaskedTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtlastname As TextBox
    Friend WithEvents txtfirstname As TextBox
    Friend WithEvents txtaddress As TextBox
    Friend WithEvents btncancel As Button
    Friend WithEvents btnsave As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnnext As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ErrorProvider1 As ErrorProvider
    Friend WithEvents BurgerDataSet8 As BurgerDataSet8
    Friend WithEvents CustomersBindingSource As BindingSource
    Friend WithEvents CustomersTableAdapter As BurgerDataSet8TableAdapters.CustomersTableAdapter
    Friend WithEvents DataGridView1 As DataGridView
End Class
