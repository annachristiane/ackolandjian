a=input('Donner les coefficients du numerateur sous forme de vecteur ligne');
b=input('Donner les coefficients du denominateur sous forme de vecteur ligne');
freqz(a,b);