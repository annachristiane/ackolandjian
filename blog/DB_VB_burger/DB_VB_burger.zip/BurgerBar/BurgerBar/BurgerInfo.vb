﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Windows.Forms
Imports System.Data.Sql
Imports System.Data
Imports System.IO

Public Class BurgerInfo



    Dim CustomersTable As DataTable
    Dim OrdersTable As DataTable
    Dim burgertable As DataTable
    Dim burgersize As Integer

    'initialization of costs  
    Dim TotalCost As Integer = 0.0
    Dim costmushrooms As Integer = 1.0
    Dim costblackolives As Integer = 1.0
    Dim costmayo As Integer = 1.0
    Dim costonions As Integer = 0.0
    Dim costmustard As Integer = 1.0
    Dim costpepperoni As Integer = 1.0
    Dim costpeppers As Integer = 0.0
    Dim costbeef As Integer = 2.0
    Dim costdoublebeef As Integer = 3.0
    Dim costcheddercheese As Integer = 1.0
    Dim costtortilla As Integer = 1.0
    Dim costfish As Integer = 1.0
    Dim costsalads As Integer = 1.0
    Dim costchickenbreast As Integer = 2.0
    Dim costfries As Integer = 1.0
    Dim costavocado As Integer = 1.0
    Dim costtomatoes As Integer = 0.0

    Dim costsmall As Integer = 4.0
    Dim costmedium As Integer = 6.0
    Dim costlarge As Integer = 8.0

    Dim SizeCost(2) As Single
    Dim rdoSize(2) As RadioButton



    Private Sub BurgerInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'BurgerDataSet13.Orders' table. You can move, or remove it, as needed.
        Me.OrdersTableAdapter4.Fill(Me.BurgerDataSet13.Orders)
        'TODO: This line of code loads data into the 'BurgerDataSet12.Orders' table. You can move, or remove it, as needed.
        Me.OrdersTableAdapter3.Fill(Me.BurgerDataSet12.Orders)
        'TODO: This line of code loads data into the 'BurgerDataSet11.Orders' table. You can move, or remove it, as needed.
        Me.OrdersTableAdapter2.Fill(Me.BurgerDataSet11.Orders)
        'TODO: This line of code loads data into the 'BurgerDataSet10.Orders' table. You can move, or remove it, as needed.
        Me.OrdersTableAdapter1.Fill(Me.BurgerDataSet10.Orders)
        'TODO: This line of code loads data into the 'BurgerDataSet7.Orders' table. You can move, or remove it, as needed.
        Me.OrdersTableAdapter.Fill(Me.BurgerDataSet7.Orders)
        'TODO: This line of code loads data into the 'BurgerDataSet5.Burgers' table. You can move, or remove it, as needed.
        Me.BurgersTableAdapter3.Fill(Me.BurgerDataSet5.Burgers)
        'TODO: This line of code loads data into the 'BurgerDataSet3.Burgers' table. You can move, or remove it, as needed.
        Me.BurgersTableAdapter2.Fill(Me.BurgerDataSet3.Burgers)
        'TODO: This line of code loads data into the 'BurgerDataSet2.Burgers' table. You can move, or remove it, as needed.
        Me.BurgersTableAdapter1.Fill(Me.BurgerDataSet2.Burgers)
        'TODO: This line of code loads data into the 'BurgerDataSet1.Relation' table. You can move, or remove it, as needed.
        Me.RelationTableAdapter.Fill(Me.BurgerDataSet1.Relation)
        'TODO: This line of code loads data into the 'BurgerDataSet.Burgers' table. You can move, or remove it, as needed.
        Me.BurgersTableAdapter.Fill(Me.BurgerDataSet.Burgers)
        Me.WindowState = FormWindowState.Maximized

        rdoSize(0) = rdosmall : SizeCost(0) = 4.0
        rdoSize(1) = rdomedium : SizeCost(1) = 6.0
        rdoSize(2) = rdolarge : SizeCost(2) = 8.0







    End Sub


    Private Sub Fill_Click(sender As Object, e As EventArgs) Handles Fill.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from burgers", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub

    Private Sub OrderComplete_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from relation", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView2.DataSource = ds.Tables(0)
    End Sub



    Private Sub rdosmall_CheckedChanged(sender As Object, e As EventArgs) Handles rdosmall.CheckedChanged
        Dim ButtonChecked As RadioButton = CType(sender, RadioButton)
        Select Case ButtonChecked.Name
            Case "rdoSmall"
                burgersize = 0
            Case "rdoMedium"
                burgersize = 1
            Case "rdoLarge"
                burgersize = 2
        End Select
    End Sub





    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Hide()
        Choose.Show()
        Customers.txtphone.Text = ""
        Customers.txtfirstname.Text = ""
        Customers.txtlastname.Text = ""
        Customers.txtaddress.Text = ""

        Customers.Label2.Enabled = True
        Customers.btnFind.Enabled = True
        Customers.txtfirstname.Enabled = False
        Customers.txtlastname.Enabled = False
        Customers.txtaddress.Enabled = False
        Customers.Label3.Enabled = False
        Customers.Label4.Enabled = False
        Customers.Label6.Enabled = False
        Customers.btnsave.Enabled = False
        Customers.btnadd.Enabled = False

        Customers.txtphone.Enabled = True
        Customers.btnnext.Enabled = False


    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Me.Hide()
        Customers.Show()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Close()


    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        If burgersize < 0 Then
            MessageBox.Show("You must choose a size", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If



        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"

        If chkMushrooms.Checked = False And chkolives.Checked = False And chkmayo.Checked = False And chkbeef.Checked = False And chkfries.Checked = False And chktomatoes.Checked = False And chkavocado.Checked = False And chkonions.Checked = False And chkpepperoni.Checked = False And chkpeppers.Checked = False And chksalads.Checked = False And chkchedder.Checked = False And chkchicken.Checked = False And chkdoublebeef.Checked = False And chkfish.Checked = False And chkmustard.Checked = False And chkjalapenos.Checked = False And chktortilla.Checked = False Then
            MessageBox.Show("You didn't order anything")

        ElseIf ComboBox1.SelectedItem = "" Then
            MessageBox.Show("You didn't choose your service helper.")
        Else

            Dim sqlquery As String = "insert Burgers(delivery,cost,size,mushrooms,blackolives,mayo,onions,mustard,pepperoni,peppers,beef,doublebeef,cheddercheese,tortilla,fish,salads,chickenbreast,fries,avocado,tomatoes,jalapenos)Values(@delivery,@cost,@size,@mushrooms,@blackolives,@mayo,@onions,@mustard,@pepperoni,@peppers,@beef,@doublebeef,@cheddercheese,@tortilla,@fish,@salads,@chickenbreast,@fries,@avocado,@tomatoes,@jalapenos)"
        Dim command As New SqlCommand(sqlquery, connection)


        If rdosmall.Checked = True Then
            command.Parameters.Add("@Size", SqlDbType.VarChar).Value = "Small"
            TotalCost = TotalCost + 4.0
        ElseIf rdomedium.Checked = True Then
            command.Parameters.Add("@Size", SqlDbType.VarChar).Value = "Medium"
            TotalCost = TotalCost + 6.0
        ElseIf rdolarge.Checked = True Then
            command.Parameters.Add("@Size", SqlDbType.VarChar).Value = "Large"
            TotalCost = TotalCost + 8.0
        End If

        If chkdeliver.Checked = True Then
            command.Parameters.Add("@delivery", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + 1.5
            'delivery cost = 1.5
        Else
            command.Parameters.Add("@delivery", SqlDbType.VarChar).Value = "No"
        End If
        If chkMushrooms.Checked = True Then
            command.Parameters.Add("@mushrooms", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + 0.5
        Else
            command.Parameters.Add("@mushrooms", SqlDbType.VarChar).Value = "No"
        End If

        If chkolives.Checked = True Then
            command.Parameters.Add("@Blackolives", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costblackolives
        Else
            command.Parameters.Add("@Blackolives", SqlDbType.VarChar).Value = "No"
        End If

        If chkmayo.Checked = True Then
            command.Parameters.Add("@Mayo", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costmayo
        Else
            command.Parameters.Add("@Mayo", SqlDbType.VarChar).Value = "No"
        End If

        If chkonions.Checked = True Then
            command.Parameters.Add("@onions", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costonions
        Else
            command.Parameters.Add("@onions", SqlDbType.VarChar).Value = "No"
        End If

        If chkmustard.Checked = True Then
            command.Parameters.Add("@mustard", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costmustard
        Else
            command.Parameters.Add("@mustard", SqlDbType.VarChar).Value = "No"
        End If

        If chkpepperoni.Checked = True Then
            command.Parameters.Add("@pepperoni", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costpepperoni
        Else
            command.Parameters.Add("@pepperoni", SqlDbType.VarChar).Value = "No"
        End If

        If chkpeppers.Checked = True Then
            command.Parameters.Add("@peppers", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costpeppers
        Else
            command.Parameters.Add("@peppers", SqlDbType.VarChar).Value = "No"
        End If

        If chkbeef.Checked = True Then
            command.Parameters.Add("@beef", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costbeef
        Else
            command.Parameters.Add("@beef", SqlDbType.VarChar).Value = "No"
        End If

        If chkdoublebeef.Checked = True Then
            command.Parameters.Add("@doublebeef", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costdoublebeef
        Else
            command.Parameters.Add("@doublebeef", SqlDbType.VarChar).Value = "No"
        End If

        If chkchedder.Checked = True Then
            command.Parameters.Add("@cheddercheese", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costcheddercheese
        Else
            command.Parameters.Add("@cheddercheese", SqlDbType.VarChar).Value = "No"
        End If

        If chktortilla.Checked = True Then
            command.Parameters.Add("@tortilla", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costtortilla
        Else
            command.Parameters.Add("@tortilla", SqlDbType.VarChar).Value = "No"
        End If

        If chkfish.Checked = True Then
            command.Parameters.Add("@fish", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costfish
        Else
            command.Parameters.Add("@fish", SqlDbType.VarChar).Value = "No"
        End If

        If chksalads.Checked = True Then
            command.Parameters.Add("@salads", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costsalads
        Else
            command.Parameters.Add("@salads", SqlDbType.VarChar).Value = "No"
        End If

        If chkchicken.Checked = True Then
            command.Parameters.Add("@chickenbreast", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costchickenbreast
        Else
            command.Parameters.Add("@chickenbreast", SqlDbType.VarChar).Value = "No"
        End If

        If chkfries.Checked = True Then
            command.Parameters.Add("@fries", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costfries
        Else
            command.Parameters.Add("@fries", SqlDbType.VarChar).Value = "No"
        End If

        If chkavocado.Checked = True Then
            command.Parameters.Add("@avocado", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costavocado
        Else
            command.Parameters.Add("@avocado", SqlDbType.VarChar).Value = "No"
        End If

        If chktomatoes.Checked = True Then
            command.Parameters.Add("@tomatoes", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + costtomatoes
        Else
            command.Parameters.Add("@tomatoes", SqlDbType.VarChar).Value = "No"
        End If

        If chkjalapenos.Checked = True Then
            command.Parameters.Add("@jalapenos", SqlDbType.VarChar).Value = "Yes"
            TotalCost = TotalCost + 0.5
        Else
            command.Parameters.Add("@jalapenos", SqlDbType.VarChar).Value = "No"
        End If



        command.Parameters.Add("@cost", SqlDbType.Int).Value = TotalCost

        connection.Open()
        command.ExecuteNonQuery()
        command.Parameters.Clear()
        connection.Close()



        Dim conn As SqlConnection = New SqlConnection()
        conn.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"


        Dim sqlqueryy As String = "insert relation(phonenumber)Values(@phonenumber)"
        Dim commandd As New SqlCommand(sqlqueryy, conn)
        commandd.Parameters.Add("@phonenumber", SqlDbType.Int).Value = txtphone.Text


        conn.Open()
        commandd.ExecuteNonQuery()
        commandd.Parameters.Clear()
        conn.Close()

        PictureBox3.Enabled = True

        Dim deliveryname As String = ComboBox1.SelectedItem


        Dim F As String = BurgerBar.Customers.f
        Dim L As String = Customers.l
        Dim a As String = Customers.a
        Dim conns As SqlConnection = New SqlConnection()
        conns.ConnectionString = "Data source= ANNA-CHRISTINA ; initial Catalog=Burger; Integrated security=True"





        Dim sqlquerys As String = "insert orders(phonenumber,orderdate,totalcost,AdminUsername,DeliveryManName)Values(@phonenumber,@orderdate,@totalcost,@AdminUsername,@DeliveryManName)"
            Dim commandos As New SqlCommand(sqlquerys, conns)
            commandos.Parameters.Add("@phonenumber", SqlDbType.Int).Value = txtphone.Text
            commandos.Parameters.Add("@orderdate", SqlDbType.Date).Value = Format(Now, "d")
            commandos.Parameters.Add("@totalcost", SqlDbType.Int).Value = TotalCost
            commandos.Parameters.Add("@AdminUsername", SqlDbType.NVarChar).Value = Login.user
            commandos.Parameters.Add("@DeliveryManName", SqlDbType.NVarChar).Value = deliveryname

            conns.Open()
            commandos.ExecuteNonQuery()
            commandos.Parameters.Clear()
            conns.Close()
            txtnotes.Text = "The total cost is: $" & TotalCost & " Phone number " & txtphone.Text & " Ordered by " & F & " " & L & " from " & a


        End If
        TotalCost = 0.0
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim connection As SqlConnection = New SqlConnection()
        connection.ConnectionString = "Data source = ANNA-CHRISTINA; initial catalog=Burger;integrated security=True"
        connection.Open()
        Dim adp As SqlDataAdapter = New SqlDataAdapter("select * from orders", connection)
        Dim ds As DataSet = New DataSet()
        adp.Fill(ds)
        DataGridView3.DataSource = ds.Tables(0)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Dim StringToPrint As String
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click

        StringToPrint = txtnotes.Text
        prndoc.Print()

    End Sub
    Private Sub prnDoc_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles prndoc.PrintPage

        Dim numChars As Integer

        Dim numLines As Integer

        Dim stringForPage As String

        Dim strFormat As New StringFormat()

        Dim PrintFont As Font

        PrintFont = txtnotes.Font

        Dim rectDraw As New RectangleF(e.MarginBounds.Left, e.MarginBounds.Top, e.MarginBounds.Width, e.MarginBounds.Height)

        Dim sizeMeasure As New SizeF(e.MarginBounds.Width, e.MarginBounds.Height - PrintFont.GetHeight(e.Graphics))

        strFormat.Trimming = StringTrimming.Word

        e.Graphics.MeasureString(StringToPrint, PrintFont, sizeMeasure, strFormat, numChars, numLines)

        stringForPage = StringToPrint.Substring(0, numChars)

        e.Graphics.DrawString(stringForPage, PrintFont, Brushes.Black, rectDraw, strFormat)

        If numChars < StringToPrint.Length Then

            StringToPrint = StringToPrint.Substring(numChars)

            e.HasMorePages = True

        Else

            e.HasMorePages = False

        End If

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class